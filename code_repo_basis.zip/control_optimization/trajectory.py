from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import torch


@dataclass
class TrajectoryMetrics:
    propagator: torch.Tensor
    dephasing_exposure: torch.Tensor
    manifold_excursion: torch.Tensor
    times: torch.Tensor | None = None
    exposure_trace: torch.Tensor | None = None
    excursion_trace: torch.Tensor | None = None
    excursion_min_trace: torch.Tensor | None = None
    excursion_max_trace: torch.Tensor | None = None


def _validate_inputs(
    time_grid: torch.Tensor,
    controls: list[torch.Tensor],
    basis_indices: list[int],
    electron_z: torch.Tensor,
) -> None:
    if time_grid.ndim != 1 or time_grid.numel() < 2:
        raise ValueError("time_grid must be a one-dimensional tensor with at least two points")
    if not controls:
        raise ValueError("at least one control channel is required")
    if any(control.shape != time_grid.shape for control in controls):
        raise ValueError("all controls must have the same shape as time_grid")
    if electron_z.ndim != 2 or electron_z.shape[0] != electron_z.shape[1]:
        raise ValueError("electron_z must be a square matrix")
    if len(basis_indices) != 8 or len(set(basis_indices)) != 8:
        raise ValueError("basis_indices must contain eight unique logical indices")
    if min(basis_indices) < 0 or max(basis_indices) >= electron_z.shape[0]:
        raise ValueError("logical basis index outside the full Hilbert space")


def propagate_with_electron_metrics(
    get_step: Callable[[list[torch.Tensor], float, float], torch.Tensor],
    time_grid: torch.Tensor,
    controls: list[torch.Tensor],
    *,
    basis_indices: list[int],
    electron_z: torch.Tensor,
    sample_stride: int = 1,
    return_traces: bool = False,
) -> TrajectoryMetrics:
    """Propagate the full unitary and accumulate electron-noise exposure.

    The logical computational basis is propagated as eight columns.  For each
    column ``j`` we evaluate

        Var_j[Z_A](t) = 1 - <Z_A>_j(t)^2,

    and the population in the electron manifold opposite to the one occupied by
    the corresponding input basis state.  The objective scalar is the time and
    logical-basis average of ``Var[Z_A]``.  Unlike the raw average population of
    one electron manifold, this quantity is not fixed by unitarity and directly
    measures susceptibility of the trajectory to longitudinal detuning.

    ``get_step`` must return the short-time propagator for one sample of the
    control channels.  The time grid is assumed to be uniform and to contain the
    left endpoints used by the repository's propagator routine.
    """
    _validate_inputs(time_grid, controls, basis_indices, electron_z)
    if sample_stride < 1:
        raise ValueError("sample_stride must be positive")

    device = electron_z.device
    dtype = electron_z.dtype
    dimension = electron_z.shape[0]
    dt_tensor = time_grid[1] - time_grid[0]
    dt = float(dt_tensor.detach().cpu())
    if dt <= 0.0:
        raise ValueError("time_grid must be strictly increasing")
    if not torch.allclose(
        torch.diff(time_grid),
        torch.full_like(torch.diff(time_grid), dt_tensor),
        atol=max(1e-15, abs(dt) * 1e-9),
        rtol=1e-7,
    ):
        raise ValueError("trajectory metric currently requires a uniform time grid")

    propagator = torch.eye(dimension, dtype=dtype, device=device)
    logical_index = torch.as_tensor(basis_indices, dtype=torch.long, device=device)
    initial_sign = torch.diagonal(electron_z).index_select(0, logical_index).real
    if not torch.allclose(initial_sign.abs(), torch.ones_like(initial_sign), atol=1e-10, rtol=0.0):
        raise ValueError("logical basis states must be electron-Z eigenstates")

    exposure_samples: list[torch.Tensor] = []
    excursion_samples: list[torch.Tensor] = []
    excursion_min_samples: list[torch.Tensor] = []
    excursion_max_samples: list[torch.Tensor] = []
    sampled_times: list[torch.Tensor] = []

    def sample(current: torch.Tensor, t_value: torch.Tensor) -> None:
        states = current.index_select(1, logical_index)
        z_states = electron_z @ states
        expectation = torch.sum(states.conj() * z_states, dim=0).real
        expectation = torch.clamp(expectation, min=-1.0, max=1.0)
        variance = torch.clamp(1.0 - expectation.square(), min=0.0)
        opposite = torch.clamp(0.5 * (1.0 - initial_sign * expectation), min=0.0, max=1.0)
        exposure_samples.append(variance.mean())
        excursion_samples.append(opposite.mean())
        excursion_min_samples.append(opposite.min())
        excursion_max_samples.append(opposite.max())
        sampled_times.append(t_value)

    # Include the exact initial point.
    sample(propagator, time_grid[0])
    for index in range(time_grid.numel() - 1):
        t_value = time_grid[index]
        channel_values = [control[index] for control in controls]
        step = get_step(channel_values, dt, float(t_value.detach().cpu()))
        propagator = step @ propagator
        if (index + 1) % sample_stride == 0 or index + 1 == time_grid.numel() - 1:
            sample(propagator, time_grid[index + 1])

    exposure_trace = torch.stack(exposure_samples)
    excursion_trace = torch.stack(excursion_samples)
    # Uniform sampled spacing except possibly the final short block.  For the
    # configured strides this mean is the normalized Riemann approximation used
    # in the optimization; final reporting can use stride one.
    dephasing_exposure = exposure_trace.mean()
    manifold_excursion = excursion_trace.mean()

    return TrajectoryMetrics(
        propagator=propagator,
        dephasing_exposure=dephasing_exposure,
        manifold_excursion=manifold_excursion,
        times=torch.stack(sampled_times) if return_traces else None,
        exposure_trace=exposure_trace if return_traces else None,
        excursion_trace=excursion_trace if return_traces else None,
        excursion_min_trace=torch.stack(excursion_min_samples) if return_traces else None,
        excursion_max_trace=torch.stack(excursion_max_samples) if return_traces else None,
    )
